﻿#include <iostream>
#include <stdlib.h>
#include <windows.graphics.h>
#include <graphics.h>
#include <conio.h>
#include<stdio.h>
#include<string>
#include <atlstr.h>
#include<vector>
#include<map>
#include <unordered_map>
#include <mutex>
#include <thread>
#include <condition_variable>

using namespace std;
void  myRandom();
void Bobm(int bobrow, int bobcom);
void RePutImage(int bobrow, int bobcom);
void ClearVectorBom();
struct pos;
#define row 13
#define com 13
#define imageCount 20
int mymap[row][com];
vector<pos> clearVector;
IMAGE img[imageCount], roleInfo;
bool isExit = false;
bool isBombCom = false;
bool isBombRow = false;
vector<pos> bobVector;
vector<pos> rePutVector;
mutex bobMutex;
mutex rePutMutex;
std::condition_variable m_ConditionVar;
struct pos
{
	int x = -1;
	int y = -1;
	inline void reset()
	{
		x = -1;
		y = -1;
	}
};
struct gameRole
{
	char username[20];
	int score;
	inline void reset()
	{
		score = 0;
	}
} role;
std::vector<std::string> split(std::string str, std::string pattern)
{
	std::string::size_type pos;
	std::vector<std::string> result;
	str += pattern;//扩展字符串以方便操作
	int size = str.size();
	for (int i = 0; i < size; i++)
	{
		pos = str.find(pattern, i);
		if (pos < size)
		{
			std::string s = str.substr(i, pos - i);
			result.push_back(s);
			i = pos + pattern.size() - 1;
		}
	}
	return result;
}


void InitUser()
{


	cout << " ******************************************************" << endl;
	cout << " ******************************************************" << endl;
	cout << " ******************************************************" << endl;
	cout << " ******************输入按键1随机生成图片*****************"<<endl;
	cout << " ******************输入按键2 炸弹炸一排******************"<<endl;
	cout << " ******************输入按键3 炸弹炸一列******************"<<endl;
	cout << " ******************输入按键4 退出游戏  ******************"<<endl;
	cout << " ******************鼠标左键点击交换图片******************"<<endl;
	cout << " ******************************************************" << endl;
	cout << " ******************************************************" << endl;
	cout << " ******************************************************" << endl;
	cout << " 请输入角色名字开始游戏:";
	std::cin >> role.username;
	role.reset();
}

char str[20] = "";
char* intTowchar(int xnum)
{
	sprintf(str, "%d", xnum);
	return str;
}
void loadResource()
{
	LPCTSTR infopath=TEXT("image/info.jpg");
	loadimage(&roleInfo, infopath);
	for (int i = 0; i < imageCount; i++)
	{
		char filename[20] = "";
		sprintf(filename, "image/%d.jpg", i);
		int num = MultiByteToWideChar(0, 0, filename, -1, NULL, 0);
		wchar_t* wide = new wchar_t[num];
		MultiByteToWideChar(0, 0, filename, -1, wide, num);
		loadimage(img + i, wide, 60, 60);
	}
}


#define offsetof(type, mumber) ((int)(&((type *)0)->mumber))
void showScore() {
	TCHAR T_username[20] = L"";
	MultiByteToWideChar(CP_ACP, 0, role.username, -1, T_username, 40);
	outtextxy(60 * 13 + 5, 100, T_username);
	outtextxy(60 * 13 + 20, 235, _itow(role.score, T_username, 10));
}

void idrawMap()
{
	int i, j;
	int x, y;
	for (i = 0; i < row; i++)
	{
		for (j = 0; j < com; j++)
		{
			x = 60 * i;
			y = 60 * j;
			putimage(x, y, &img[mymap[i][j]]);
		}
	}
	putimage(60*13, 0, &roleInfo);
	showScore();
}



void mySetColor()
{
	
}

bool checkBlockRemove()
{
	int i = 0;
	int isRightOrDown = 0;//0 为没有连续的 1 为向右连续 2为 向左连续
	vector<pos> clearTempVector;
	int Downcount = 1;
	int RowCount = 1;
	for (; i < row;)
	{
		int j = 0;
		for (; j < com-1;)
		{
			if (Downcount == 1)
			{
				pos p;
				p.x = i;
				p.y = j ;
				clearTempVector.clear();
				clearTempVector.push_back(p);
			}
			int down = mymap[i][j + 1];
			if (down == mymap[i][j])
			{
				pos p;
				p.x = i;
				p.y = j+1;
				clearTempVector.push_back(p);
				Downcount++;
				if (j == com - 1) goto H;
			}
			else {
			H:
				if (Downcount >= 3)
				{
					for (auto it = clearTempVector.begin(); it != clearTempVector.end(); ++it)
					{
						clearVector.push_back(*it);
					}
				}
				Downcount = 1;
			}
			++j;
		}
		++i;
	}
	int tempI = 0;
	int tempJ = 0;
	i = 0;
	bool isComb = false;
	for (; i < row-1;)
	{
	M:
		int j = tempJ;
		for (; j < com ;)
		{
			if (RowCount == 1)
			{
				pos p;
				p.x = i;
				p.y = j;
				clearTempVector.clear();
				clearTempVector.push_back(p);
			}
			
			int right = mymap[i + 1][j];
			if (right == mymap[i][j])
			{
				pos p;
				p.x = i+1;
				p.y = j;
				if (!isComb)
				{
					tempI = i;
					tempJ = j;
					isComb = true;
				}
				clearTempVector.push_back(p);
				RowCount++;
				if (i == row - 1) goto N;
				break;
			}
			else {
			N:
				if (RowCount >= 3)
				{
					for (auto it = clearTempVector.begin(); it != clearTempVector.end(); ++it)
					{
						clearVector.push_back(*it);
					}
				}
				RowCount = 1;
				if (isComb)
				{
					isComb = false;
					i = tempI;
					++tempJ;
					goto M;
				}
				
			}
			++j;
		}
		if (!isComb)
		{
			tempJ = 0;
		}
		++i;
	}
	if (clearVector.size() >= 3) {
		return true;
	}
	return false;
	
}

void keyDown()
{
	char userkey;
	while(1)
	{
		if (isExit)
		{
			break;
		}
		userkey = _getch();
		switch (userkey)
		{

		case 49:
			myRandom();
			idrawMap();
			checkBlockRemove();
			break;
		case 50:
			isBombRow = true;
			break;
		case 51:
			isBombCom = true;
			break;
		case 52:
			isExit = true;
			break;
		default:
			cout << userkey << endl;
			break;
		}
		
	}
}

void mouseClick()
{
	MOUSEMSG m;  //定义鼠标消息
	int mouse;
	pos first;
	first.reset();
	while (1)
	{
		if (isExit)
		{
			break;
		}
		m = GetMouseMsg();
		int rowClick = 0, comClick = 0;
		if (m.uMsg == WM_LBUTTONDOWN) {
			putpixel(m.x, m.y, WHITE); //鼠标移动时画小白点
			rowClick = m.x / 60;
			comClick = m.y / 60;
			if (isBombCom)
			{
				vector<pos> locakbobVector;
				for (int i = 0; i < row; ++i)
				{
					pos bobPos;
					bobPos.x = rowClick;
					bobPos.y = i;
					locakbobVector.push_back(bobPos);
				}
				{
					lock_guard<mutex> mylockguard(bobMutex);
					bobVector.swap(locakbobVector);
				}
				isBombCom = false;
				continue;
			}
			if (isBombRow) {
				vector<pos> locakbobVector;
				for (int i = 0; i < row; ++i)
				{
					pos bobPos;
					bobPos.x = i;
					bobPos.y = comClick;
					locakbobVector.push_back(bobPos);
				}
				{
					lock_guard<mutex> mylockguard(bobMutex);
					bobVector.swap(locakbobVector);
				}
				isBombRow = false;
				continue;

			}
			if (first.x == -1)
			{
				if (mymap[rowClick][comClick] == 17) {
					continue;
				}
				first.x = rowClick;
				first.y = comClick;
			}
			else {
				if (mymap[rowClick][comClick] == 17) {
					continue;
				}
				if ((rowClick == (first.x + 1)&& comClick==first.y) ||
					(rowClick == (first.x -1 ) && comClick == first.y) ||
					(comClick == (first.y + 1)&& rowClick == first.x)||
					(comClick == (first.y - 1) && rowClick == first.x)
					)
				{
					int temp = mymap[first.x][first.y];
					mymap[first.x][first.y] = mymap[rowClick][comClick];
					mymap[rowClick][comClick] = temp;
					idrawMap();
					bool isTrue=checkBlockRemove();
					if (isTrue)
					{
						ClearVectorBom();
					}
					else {
						Sleep(300);
						mymap[rowClick][comClick] = mymap[first.x][first.y];
						mymap[first.x][first.y] = temp;
						idrawMap();
					}
					first.reset();
					continue;
				}
				
			}
		}
	}

}

void ClearVectorBom()
{
	vector<pos> locakbobVector;
	clearVector.swap(locakbobVector);
	{
		lock_guard<mutex> mylockguard(bobMutex);
		bobVector.swap(locakbobVector);
	}
}

void Bobm(int bobrow,int bobcom)
{
	int x = 60 * bobrow;
	int y = 60 * bobcom;
	mymap[bobrow][bobcom] = 17;
	putimage(x, y, &img[mymap[bobrow][bobcom]]);
}


void RePutImage(int bobrow, int bobcom)
{
	int x = 60 * bobrow;
	int y = 60 * bobcom;
	int data = rand() % 17;
	mymap[bobrow][bobcom] = data;
	putimage(x, y, &img[mymap[bobrow][bobcom]]);
}


void myRandom()
{
	srand(time(NULL));
	int i = 0;
	for (; i < row; ++i)
	{
		int j = 0;
		for (; j < com; ++j)
		{
			int data = rand() % 17;
			mymap[i][j] = data;
		}
	}
}

void bobFun()
{
	while (1)
	{
		if (isExit)
		{
			break;
		}
		vector<pos> locakbobVector;
		while (!bobVector.empty())
		{
			vector<pos> locakbobVectorTwo;
			{
					lock_guard<mutex> mylockguard(bobMutex);
					bobVector.swap(locakbobVectorTwo);
			}
			for (auto it = locakbobVectorTwo.begin(); it != locakbobVectorTwo.end(); ++it)
			{
					locakbobVector.push_back(*it);
					Bobm(it->x, it->y);
			}
			idrawMap();
			{
				unique_lock<mutex> mylockguard(rePutMutex);
				while (!rePutVector.empty())
				{
					m_ConditionVar.wait(mylockguard);
				}
				locakbobVector.swap(rePutVector);
			}
		}
	}

}


void rePutFun()
{
	while (1)
	{
		if (isExit)
		{
			break;
		}
		while (!rePutVector.empty())
		{
			vector<pos> locakbobVector;
			{
				unique_lock<mutex> mylockguard(rePutMutex);
				rePutVector.swap(locakbobVector);
			}
			Sleep(1000);
			srand(time(NULL));
			for (auto it = locakbobVector.begin(); it != locakbobVector.end(); ++it) {
				RePutImage(it->x, it->y);
			}
			m_ConditionVar.notify_one();
			idrawMap();
		}
	}
}

int main()
{
	myRandom();
	InitUser();
	initgraph(60*14, 60*13);
	loadResource();
	idrawMap();
	int i = 0;
	thread t1(keyDown);
	thread t2(mouseClick);
	thread t3(bobFun);
	thread t4(rePutFun);
	checkBlockRemove();
	ClearVectorBom();
	t1.join();
	t2.join();
	t3.join();
	t4.join();
	closegraph();
	return 0;
}

// 运行程序: Ctrl + F5 或调试 >“开始执行(不调试)”菜单
// 调试程序: F5 或调试 >“开始调试”菜单

// 入门使用技巧: 
//   1. 使用解决方案资源管理器窗口添加/管理文件
//   2. 使用团队资源管理器窗口连接到源代码管理
//   3. 使用输出窗口查看生成输出和其他消息
//   4. 使用错误列表窗口查看错误
//   5. 转到“项目”>“添加新项”以创建新的代码文件，或转到“项目”>“添加现有项”以将现有代码文件添加到项目
//   6. 将来，若要再次打开此项目，请转到“文件”>“打开”>“项目”并选择 .sln 文件
