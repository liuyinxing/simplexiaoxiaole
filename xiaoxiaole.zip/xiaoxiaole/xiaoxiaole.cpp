﻿#include <iostream>
#include <stdlib.h>
#include <windows.graphics.h>
#include <graphics.h>
#include <conio.h>
#include<stdio.h>
#include<string>
#include <atlstr.h>
#include<vector>
#include<map>
#include <unordered_map>
#include <mutex>
#include <thread>
#include <condition_variable>

using namespace std;
void  myRandom();
void Bobm(int bobrow, int bobcom);
void RePutImage(int bobrow, int bobcom);
void ClearVectorBom();
struct pos;
#define row 13
#define com 13
#define imageCount 20
int mymap[row][com];
vector<vector<pos>> clearVector;
IMAGE img[imageCount], roleInfo,backGround;
bool isExit = false;
bool isBombCom = false;
bool isBombRow = false;
vector<vector<pos>> bobVector;
vector<vector<pos>> rePutVector;
mutex bobMutex;
mutex rePutMutex;
mutex isExitMutex;
mutex isBombComMutex;
mutex isBombRowMutex;

std::condition_variable m_ConditionVar;


struct pos
{
	int x = -1;
	int y = -1;
	inline void reset()
	{
		x = -1;
		y = -1;
	}
};
pos first;

struct gameRole
{
	char username[20];
	int score;
	inline void reset()
	{
		score = 0;
	}
} role;
//分割字符串
std::vector<std::string> split(std::string str, std::string pattern)
{
	std::string::size_type pos;
	std::vector<std::string> result;
	str += pattern;//扩展字符串以方便操作
	int size = str.size();
	for (int i = 0; i < size; i++)
	{
		pos = str.find(pattern, i);
		if (pos < size)
		{
			std::string s = str.substr(i, pos - i);
			result.push_back(s);
			i = pos + pattern.size() - 1;
		}
	}
	return result;
}

//初始化界面
void InitUser()
{


	cout << " ******************************************************" << endl;
	cout << " ******************************************************" << endl;
	cout << " ******************************************************" << endl;
	cout << " ******************输入按键1随机生成图片*****************"<<endl;
	cout << " ******************输入按键2 炸弹炸一排******************"<<endl;
	cout << " ******************输入按键3 炸弹炸一列******************"<<endl;
	cout << " ******************输入按键4 退出游戏  ******************"<<endl;
	cout << " ******************鼠标左键点击交换图片******************"<<endl;
	cout << " ******************************************************" << endl;
	cout << " ******************************************************" << endl;
	cout << " ******************************************************" << endl;
	cout << " 请输入角色名字开始游戏:";
	std::cin >> role.username;
	role.reset();
}

char str[20] = "";
char* intTowchar(int xnum)
{
	sprintf(str, "%d", xnum);
	return str;
}

//读取图片
void loadResource()
{

	LPCTSTR infopath=TEXT("image/info.png");
	loadimage(&roleInfo, infopath,60,60*13);
	LPCTSTR backgroundpath = TEXT("image/background.png");
	loadimage(&backGround, backgroundpath,60*14,60*13);
	putimage(0, 0, &backGround);
	for (int i = 0; i < imageCount; i++)
	{
		char filename[20] = "";
		sprintf(filename, "image/%d.png", i);
		int num = MultiByteToWideChar(0, 0, filename, -1, NULL, 0);
		wchar_t* wide = new wchar_t[num];
		MultiByteToWideChar(0, 0, filename, -1, wide, num);
		loadimage(img + i, wide, 60, 60,true);
	}
}



#define offsetof(type, mumber) ((int)(&((type *)0)->mumber))


void showScore() {
	TCHAR T_username[20] = L"";
	MultiByteToWideChar(CP_ACP, 0, role.username, -1, T_username, 40);
	TCHAR T_username1[20] = L"姓名:";
	outtextxy(60 * 13 + 5, 100, T_username1);
	outtextxy(60 * 13 + 5, 120, T_username);
	outtextxy(60 * 13 + 5, 210, L"得分:");
	outtextxy(60 * 13 + 20, 235, _itow(role.score, T_username, 10));
}

void idrawMap()
{
	int i, j;
	int x, y;
	for (i = 0; i < row; i++)
	{
		for (j = 0; j < com; j++)
		{
			x = 60 * i;
			y = 60 * j;
			putimage(x, y, &img[mymap[i][j]]);
			
		}
	}

	putimage(60*13, 0, &roleInfo);
	showScore();
}



void mySetColor()
{
	
}

bool checkBlockRemove()
{
	int i = 0;

	vector<pos> clearTempVector;
	int Downcount = 1;
	int RowCount = 1;
	for (; i < row;)
	{
		int j = 0;
		for (; j < com-1;)
		{
			if (Downcount == 1)
			{
				pos p;
				p.x = i;
				p.y = j ;
				clearTempVector.clear();
				clearTempVector.push_back(p);
			}
			int down = mymap[i][j + 1];
			if (down == mymap[i][j])
			{
				pos p;
				p.x = i;
				p.y = j+1;
				clearTempVector.push_back(p);
				Downcount++;
				if (j == com - 1) goto H;
			}
			else {
			H:
				if (Downcount >= 3)
				{
					//for (auto it = clearTempVector.begin(); it != clearTempVector.end(); ++it)
					//{
						clearVector.push_back(clearTempVector);
				//	}
				}
				Downcount = 1;
			}
			++j;
		}
		++i;
	}
	int tempI = 0;
	int tempJ = 0;
	i = 0;
	bool isComb = false;
	for (; i < row-1;)
	{
	M:
		int j = tempJ;
		for (; j < com ;)
		{
			if (RowCount == 1)
			{
				pos p;
				p.x = i;
				p.y = j;
				clearTempVector.clear();
				clearTempVector.push_back(p);
			}
			
			int right = mymap[i + 1][j];
			if (right == mymap[i][j])
			{
				pos p;
				p.x = i+1;
				p.y = j;
				if (!isComb)
				{
					tempI = i;
					tempJ = j;
					isComb = true;
				}
				clearTempVector.push_back(p);
				RowCount++;
				if (i == row - 1) goto N;
				break;
			}
			else {
			N:
				if (RowCount >= 3)
				{
					//for (auto it = clearTempVector.begin(); it != clearTempVector.end(); ++it)
				//	{
						clearVector.push_back(clearTempVector);
					//}
				}
				RowCount = 1;
				if (isComb)
				{
					isComb = false;
					i = tempI;
					++tempJ;
					goto M;
				}
			}
			++j;
		}
		if (!isComb)
		{
			tempJ = 0;
		}
		++i;
	}
	if (clearVector.size() >= 1) {
		return true;
	}
	return false;
	
}

void keyDown()
{
	char userkey;
	while(1)
	{
		if (isExit)
		{
			break;
		}
		userkey = _getch();
		switch (userkey)
		{
		case 49:
			first.reset();
			myRandom();
			idrawMap();
			checkBlockRemove();
			ClearVectorBom();
			break;
		case 50:
			isBombRow = true;
			break;
		case 51:

			isBombCom = true;
			break;
		case 52:
			isExit = true;
			break;
		default:
			cout << userkey << endl;
			break;
		}
		
	}
}

void mouseClick()
{
	MOUSEMSG m;  //定义鼠标消息
	int mouse;
	while (1)
	{
		if (isExit)
		{
			break;
		}
		m = GetMouseMsg();
		int rowClick = 0, comClick = 0;
		if (m.uMsg == WM_LBUTTONDOWN) {
			putpixel(m.x, m.y, WHITE); //鼠标移动时画小白点
			rowClick = m.x / 60;
			comClick = m.y / 60;
			{
				std::unique_lock<mutex> mylock(isBombComMutex);
				if (isBombCom) goto isBombComTrue;
			}
			{
				std::unique_lock<mutex> mylock(isBombRowMutex);
				if (isBombRow) goto isBombRowTrue;
			}
			goto OnBomb;
			{
			isBombComTrue:
				isBombCom = false;
				vector<pos> locakbobVector;
				for (int i = 0; i < row; ++i)
				{
					pos bobPos;
					bobPos.x = rowClick;
					bobPos.y = i;
					locakbobVector.push_back(bobPos);
				}
				{
					lock_guard<mutex> mylockguard(bobMutex);
					bobVector.push_back(locakbobVector);
				}
				continue;
			}
			isBombRowTrue: {
				isBombRow = false;
				vector<pos> locakbobVector;
				for (int i = 0; i < row; ++i)
				{
					pos bobPos;
					bobPos.x = i;
					bobPos.y = comClick;
					locakbobVector.push_back(bobPos);
				}
				{
					lock_guard<mutex> mylockguard(bobMutex);
					bobVector.push_back(locakbobVector);
				}		
				continue;
			}
			OnBomb:
			if (first.x == -1)
			{
				if (mymap[rowClick][comClick] == 17) {
					continue;
				}
				first.x = rowClick;
				first.y = comClick;
			}
			else {
				if (mymap[rowClick][comClick] == 17) {
					continue;
				}
				if ((rowClick == (first.x + 1)&& comClick==first.y) ||
					(rowClick == (first.x -1 ) && comClick == first.y) ||
					(comClick == (first.y + 1)&& rowClick == first.x)||
					(comClick == (first.y - 1) && rowClick == first.x)
					)
				{
					int temp = mymap[first.x][first.y];
					mymap[first.x][first.y] = mymap[rowClick][comClick];
					mymap[rowClick][comClick] = temp;
					idrawMap();
					bool isTrue=checkBlockRemove();
					if (isTrue)
					{
						ClearVectorBom();
					}
					else {
						Sleep(300);
						mymap[rowClick][comClick] = mymap[first.x][first.y];
						mymap[first.x][first.y] = temp;
						idrawMap();
					}
					first.reset();
					continue;
				}
				
			}
		}
	}

}

void ClearVectorBom()
{
	vector<vector<pos>> locakbobVector;
	clearVector.swap(locakbobVector);
	{
		lock_guard<mutex> mylockguard(bobMutex);
		bobVector.swap(locakbobVector);
	}
}

void Bobm(int bobrow,int bobcom)
{
	int x = 60 * bobrow;
	int y = 60 * bobcom;
	mymap[bobrow][bobcom] = 17;
	putimage(x, y, &img[mymap[bobrow][bobcom]]);
}


void RePutImage(int bobrow, int bobcom)
{
	int x = 60 * bobrow;
	int y = 60 * bobcom;
	int data = rand() % 17;
	mymap[bobrow][bobcom] = data;
	putimage(x, y, &img[mymap[bobrow][bobcom]]);
}


void myRandom()
{
	srand(time(NULL));
	int i = 0;
	for (; i < row; ++i)
	{
		int j = 0;
		for (; j < com; ++j)
		{
			int data = rand() % 17;
			mymap[i][j] = data;
		}
	}
}

void bobFun()
{
	while (1)
	{
		if (isExit)
		{
			break;
		}
		vector<vector<pos>> locakbobVector;
		while (!bobVector.empty())
		{
			vector<vector<pos>> locakbobVectorTwo;
			{
					lock_guard<mutex> mylockguard(bobMutex);
					bobVector.swap(locakbobVectorTwo);
			}
			for (vector<vector<pos>>::iterator it = locakbobVectorTwo.begin(); it != locakbobVectorTwo.end(); ++it)
			{
					locakbobVector.push_back(*it);
					for (auto it1 = begin(*it);it1!= end(*it);++it1)
					{
						Bobm(it1->x, it1->y);
					}
					
			}
			idrawMap();
			{
				unique_lock<mutex> mylockguard(rePutMutex);
				while (!rePutVector.empty())
				{
					m_ConditionVar.wait(mylockguard);
				}
				locakbobVector.swap(rePutVector);
			}
		}
	}

}


void rePutFun()
{
	while (1)
	{
		if (isExit)
		{
			break;
		}
		while (!rePutVector.empty())
		{
			vector<vector<pos>> locakbobVector;
			{
				unique_lock<mutex> mylockguard(rePutMutex);
				rePutVector.swap(locakbobVector);
			}
			Sleep(1000);
			srand(time(NULL));
			//for (auto it = locakbobVector.begin(); it != locakbobVector.end(); ++it) {
			bool isCow = false;
			for (vector<vector<pos>>::iterator it1 = locakbobVector.begin(); it1 != locakbobVector.end(); ++it1)
			{
				if ((*it1)[0].y!= (*it1)[1].y) { isCow = true; };
				if (!isCow) {
					for (auto it = (*it1).begin(); it != (*it1).end(); ++it) {
						//	RePutImage(it.x, it.y);
						int x = 60 * it->x;
						int y = 60 * it->y;
						int data = rand() % 17;
						while (it->y)
						{
							mymap[it->x][it->y] = mymap[it->x][it->y - 1];
							putimage(x, y, &img[mymap[it->x][it->y]]);
							--it->y;
						}
						mymap[it->x][it->y] = data;
						putimage(x, y, &img[mymap[it->x][it->y]]);

					}
				}
				else {
					bool isRow = false;
					int  i = 0;
					std::reverse((*it1).begin(), (*it1).end());
					for (auto it = (*it1).begin(); it != (*it1).end(); ++it) {
						//	RePutImage(it.x, it.y);
						int x = 60 * it->x;
						int y = 60 * it->y;
						int data = rand() % 17;
						int count = (*it1).size();
						if (!isRow)
						{
							while (it->y)
							{
								mymap[it->x][it->y] = mymap[it->x][it->y - count];
								putimage(x, y, &img[mymap[it->x][it->y]]);
								--it->y;
							}
						}
						mymap[it->x][i] = data;
						isRow = true;
						putimage(x, y, &img[mymap[it->x][i]]);
						++i;
					
					}
				}

				m_ConditionVar.notify_one();
				idrawMap();
			}
		
		}
	}
};

int main()
{
	first.reset();
	myRandom();
	InitUser();
	HWND a=initgraph(60*14, 60*13);
	loadResource();
	idrawMap();
	int i = 0;
	thread t1(keyDown);
	thread t2(mouseClick);
	thread t3(bobFun);
	thread t4(rePutFun);
	checkBlockRemove();
	ClearVectorBom();
	t1.join();
	t2.join();
	t3.join();
	t4.join();
	closegraph();
	return 0;
}

// 运行程序: Ctrl + F5 或调试 >“开始执行(不调试)”菜单
// 调试程序: F5 或调试 >“开始调试”菜单

// 入门使用技巧: 
//   1. 使用解决方案资源管理器窗口添加/管理文件
//   2. 使用团队资源管理器窗口连接到源代码管理
//   3. 使用输出窗口查看生成输出和其他消息
//   4. 使用错误列表窗口查看错误
//   5. 转到“项目”>“添加新项”以创建新的代码文件，或转到“项目”>“添加现有项”以将现有代码文件添加到项目
//   6. 将来，若要再次打开此项目，请转到“文件”>“打开”>“项目”并选择 .sln 文件
